def main():
	i = 0
	while i < 10:
		print('hello world') # Python 3.X
		#print 'hello world' # Python 2.X
		i = i + 1
		if (i == 5):
			break

if __name__ == '__main__': main()
